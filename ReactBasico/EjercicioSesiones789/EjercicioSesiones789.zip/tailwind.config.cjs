/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./index.html", "./src/**/*.{js,jsx,css,scss}"],
  theme: {
    extend: {},
  },
  plugins: [],
}
